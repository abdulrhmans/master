1. Extract WinOdooPrinterConnector
2. Edit printer.conf according to your configuration
	[server]
	host = host or IP address for your Odoo server
	port = port number for Odoo server
	dbname =  database name for Odoo server
	user = user
	password = password

	[connector]
	token = token received in Connector configuration in Odoo interface
3. Save printer.conf
4. Double click in connector.bat
5. Press Ctrl + C to shutdown the connector